<?php return array (
  'my-parent-live' => 'App\\Http\\Livewire\\MyParentLive',
  'test' => 'App\\Http\\Livewire\\Test',
);