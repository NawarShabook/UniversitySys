<?php

return[
    'name' =>'Name',
    'name_college_en'=>'Student Name',
    'name_college_ar'=>'Student name(ar)',
    'Processes'=>'Processes'
];
