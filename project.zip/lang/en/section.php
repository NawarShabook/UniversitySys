<?php

return[
    'name_section_en'=>'section name',
    'name_section_ar'=>'section name(ar)',
    'section'=>'Section',
    'add'=>'Add Section',
    'name'=>'Name',
    'name_en'=>'Name_en',
    'status'=>'Status',
    'processes'=>'Processes',
];
 