<?php

return[
    'teacher' => 'Teacher',
    'teachers' => 'Teachers',
    'bachelor' => 'Bachelor',
    'master' => 'Master',
    'doctor' => 'Doctor',
    'edu_level' =>'Education Level',

];
