<?php

return[
    'name' =>'Name',
    'name_college_en'=>'College Name',
    'name_college_ar'=>'college name(ar)',
    'choose'=>'Choose College',
    'note'=>'note',
    'Processes'=>'Processes'
];
