<?php

return[
    'name' =>'Name',
    'name_ar' =>'Arabic Name',
    'name_en' =>'English Name',
    'email' =>'email',
    'password' =>'Password',
    'add' =>'Add',
    'name' =>'Name',
    'show' =>'Show',
    'delete' => 'Delete',
    'submit' => 'Submit',
    'close' => 'Close',
    'reset' => 'Reset',
    'choose' => 'Choose',
    'college' => 'College',
    'level' => 'Studing Level',
    'section' => 'Section',
    'student' => 'Student',
    'gender' => 'Gender',
    'male' => 'Male',
    'female' => 'Female',
    'birthday' => 'Birthday',
    'actions'=>'Actions'
];
