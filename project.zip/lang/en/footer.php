<?php

return[
    'name' =>'AL-Sham University Students',
    'value' => 'Informatics Engineering'
];
