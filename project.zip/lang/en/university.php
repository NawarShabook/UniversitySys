<?php

return[
    'managment'=>'University Managment System',

    'colleges'=>'Colleges ',

    'add_fac'=>'Add Colleges',
    'show_fac'=>'Show Colleges',
    'classroom'=>'Classroom',
    'add_classroom'=>'Add Classroom',
];
