<?php

return[
    'name' =>'Dashboard',
    'count'=>'Colleges Count',
    'countpar'=>'Parent Count',
    'countDr'=>'Teacher Count'
];
