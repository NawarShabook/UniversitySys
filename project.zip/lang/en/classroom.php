<?php

return[
    'name' =>'Name',
    'name_college'=>'College Name',
    'Processes'=>'Processes',
    'class'=>'ClassRoom',
    'classt'=>'ClassRoom',
];
