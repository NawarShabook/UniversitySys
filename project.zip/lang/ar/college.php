<?php

return[
    'name' =>'الاسم',
    'name_college_ar'=>'اسم الكلية',
    'name_college_en'=>'اسم الكلية (إنكليزي)',
    'choose'=>'اختار الكلية',
    'note'=>'ملاحظات',
    'Processes'=>'إجراءات'
]; 
