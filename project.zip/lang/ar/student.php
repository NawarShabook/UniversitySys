<?php

return[
    'name' =>'الاسم',
    'name_student_ar'=>'اسم الطالب',
    'name_student_en'=>'اسم الطالب (إنكليزي)',
    'Processes'=>'إجراءات'
]; 
