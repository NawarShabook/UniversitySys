<?php

return[
    'managment'=>'نظام لإدارة الجامعات ',
    'colleges'=>'  الكليات ',
    'add_fac'=>'إضافة الكليات',
    'show_fac'=>'عرض الكليات',
    'classroom'=>'السنوات الدراسية',
    'add_classroom'=>'إضافة السنوات الدراسية',

];
