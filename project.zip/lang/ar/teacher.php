<?php

return[
    'teacher' => 'مدرس',
    'teachers' => 'المدرسين',
    'bachelor' => 'إجازة',
    'master' => 'ماجستير',
    'doctor' => 'دكتوراه',
    'edu_level' =>'المستوى العلمي',

];
