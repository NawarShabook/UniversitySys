<?php

return[
    'class' => 'السنوات الدراسية',
    'classt' => 'السنة الدراسية',
    'name' =>'الاسم',
    'name_college'=>'اسم الكلية',
    'Processes'=>'إجراءات',
];
