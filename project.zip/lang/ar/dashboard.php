<?php

return[
    'name' =>'لوحة التحكم ',
    'count'=>'عدد الكليات ',
    'countpar' =>'عدد اولياء الامور',
    'countDr'=>'عدد دكتور'
];
