<?php

return[
    'name' =>'الاسم',
    'name_ar' =>'الاسم بالعربية',
    'name_en' =>'الاسم بالإنكليزية',
    'email' =>'الإيميل',
    'password' =>'كلمة المرور',
    'add' =>'إضافة',
    'show' =>'إظهار',
    'delete' => 'حذف',
    'submit' => 'تأكيد',
    'close' => 'إغلاق',
    'reset' => 'إعادة ضبط',
    'choose' => 'اختر',
    'college' => 'الكلية',
    'level' => 'السنة الدراسية',
    'section' => 'القسم',
    'student' => 'Student',
    'gender' => 'الجنس',
    'male' => 'ذكر',
    'female' => 'أنثى',
    'birthday' => 'تاريخ الميلاد',
    'actions'=>'إجراءات'
];
