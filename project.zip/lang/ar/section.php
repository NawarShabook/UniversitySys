<?php

return[
    'name_section_ar'=>'اسم القسم',
    'name_section_en'=>'اسم القسم (إنكليزي)',
    'section'=>'أقسام الكليات',
    'add'=>'إضافة قسم',
    'name'=>'الاسم',
    'name_en'=>'Name_en',
    'status'=>'الحالة',
    'processes' =>'إجراءات'
];
